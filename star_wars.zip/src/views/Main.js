import React, { useEffect } from "react";



const Main = (props) => {
    return (
        <div>
        </div>
    )
}

export default Main;